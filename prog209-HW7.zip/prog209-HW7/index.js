const PASSCODE = "1234";

document.addEventListener("DOMContentLoaded", function () {

// login
let userInputedPasscode = "";
while(userInputedPasscode.trim() != PASSCODE || userInputePasscode == "") {
    userInputedPasscode = prompt("Please enter your passcode");
} 


})
